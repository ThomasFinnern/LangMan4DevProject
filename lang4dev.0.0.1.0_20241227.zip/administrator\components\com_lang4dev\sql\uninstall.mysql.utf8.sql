#
# uninstall sql for lang4dev
#

DROP TABLE IF EXISTS `#__lang4dev_projects`;
DROP TABLE IF EXISTS `#__lang4dev_subprojects`;

